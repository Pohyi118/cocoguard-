# KokoShield Field Desk

Universiti Malaya · Global Sustainability Challenge · Food Resilience

## Run the prototype

Open `KokoShield_Prototype.html` in a recent desktop or mobile browser. Everything runs inside the page. The browser stores observations and samples for this profile. Export the CSV before moving to a different device. Photos stay in the browser. The CSV includes a photo-attached flag. Both farm maps and the preset findings are illustrative.

1. Open **Field plan** and generate a route for the default 30-minute budget. Change the budget, switch between the priority and usual routes, or select a block to inspect the reason.
2. Choose **Log observation**, enter the count and notes, and optionally attach a photo. Save for review, then confirm or rule out the observation in **Scout log**.
3. In **Compare**, see both routes under the same time budget. The comparison counts preset mock findings. A field trial would compare timed walks and verify missed cases through follow-up.
4. Change the crop menu in the top bar to **Rice, China**. The same field workflow uses a separate crop profile, risk indicators and observation history.
5. Open **Sensor node**, drag to rotate and choose **Exploded**. Import the example JSON or click **Simulate sample**. Choose **Use sample in field plan** to bring that reading into the current crop's route inputs.

On a phone the four sections move to a tab bar at the bottom of the screen. The page embeds its typeface (IBM Plex Sans, SIL Open Font License), so it looks the same offline.

The demonstration adds priority for pre-marked wet blocks when a wet scenario is selected. Prior records also contribute to rank. Closed blocks are excluded. Stop durations are illustrative estimates. The mouse-selectable map is schematic. Field thresholds require review with a grower and adviser.

## Add it to Bubble

On a Bubble web app page, add the built-in **HTML** visual element. Open `KokoShield_Bubble_Embed.txt` in a text editor and paste the whole string into the element's HTML field. The snippet contains its own iframe, so leave **Display as an iFrame** clear. Size the Bubble element to its parent width and allow about 1100 px of height. The iframe can scroll on smaller screens. Use **Preview** to verify field planning, logging and downloads in run mode.

The embed keeps current data in browser storage. A native multi-user version would need Bubble data types and app-level access controls. Suggested types are Farm, Block, Scouting Round, Observation, Review and Telemetry Snapshot. CSV export supports handoff of demo observations. There is no upload endpoint or live sensor connection in this package.

Bubble references

- [HTML visual element](https://manual.bubble.io/core-resources/elements/visual-elements)
- [Preview a web app](https://manual.bubble.io/help-guides/previewing-your-app/previewing-a-web-app)

## Hardware concept

The baseline trial can run with manual or public weather data. The optional **Field Node** shows where local observations can enter the same workflow.

| Part or signal | Design |
| --- | --- |
| Controller | ESP32-class development board. The 43 × 23 mm model is a size envelope. Select a board and check clearance before fabrication. |
| Air temperature and humidity | External sensor breakout inside the ventilated hood, away from the electronics chamber. |
| 24-hour rainfall | A separate local gauge or a manual record. The humidity sensor does not measure rain. |
| Leaf wetness | Separate leaf-wetness input or field record for the rice scenario. Relative humidity is a separate reading. |
| Enclosure | 86 × 62 × 32 mm base before tabs, 3.2 mm lid, external ventilated hood with cable access. |
| Assembly | Lid fasteners and the hood carrier or bracket require a fit check with selected parts. Cable strain relief, gasketing and weather tests are pending. |

**CAD** contains an editable STEP assembly, its CadQuery source, three part STL meshes and a colored GLB. The CAD and STL dimensions are in millimetres. The GLB scene uses metres. The STL baseline is a shape and clearance mock-up. Component mounting, print tolerance, actual sensor location and outdoor readiness need physical validation.

`Telemetry_Example.json` is the import fixture. Its fields are `air_c`, `rh_pct`, `rain_mm` and `leaf_wetness_h`. All four inputs are numeric. A future field integration can attach device ID, measurement time and provenance when delivering the values to a lab or farm data store.
