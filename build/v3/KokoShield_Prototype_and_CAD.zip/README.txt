KokoShield prototype and Field Node CAD (attachment to the GSC 2026-27 Ignite proposal)

KokoShield_Prototype.html  The Field Desk prototype. Open it in Chrome or Edge on a laptop or phone.
                           Demo farm and demo data only. Records are stored in the browser.
CAD/                       Field Node concept: STEP assembly, STL parts, GLB viewer model, CadQuery source.
                           A CAD design only: not printed, no power design, not tested outdoors.
Telemetry_Example.json     Example reading the Sensor node page can import (demo values).
